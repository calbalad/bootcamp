export const environment = {
  production: true,
  ERROR_LEVEL: 1,
  apiURL: '/api/',
};
